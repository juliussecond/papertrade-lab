import os
import sqlite3
from datetime import datetime, timezone

import pandas as pd
import plotly.graph_objects as go
import requests
import streamlit as st
from streamlit_autorefresh import st_autorefresh

# PaperTrade Lab v2 — simulation only. No broker connection and no real orders.
st.set_page_config(page_title="PaperTrade Lab", page_icon="📈", layout="wide")

DB = "papertrade_v2.db"
START_CASH = 10_000.0
FEE_RATE = 0.001
SLIPPAGE_RATE = 0.0005
WATCHLIST = ["AAPL", "MSFT", "NVDA", "SPY", "QQQ"]
INTERVAL = "5min"
REFRESH_MS = 60_000

def connect():
    return sqlite3.connect(DB, check_same_thread=False)

def setup():
    with connect() as c:
        c.execute("CREATE TABLE IF NOT EXISTS account (id INTEGER PRIMARY KEY, cash REAL NOT NULL)")
        c.execute("""CREATE TABLE IF NOT EXISTS positions
                     (symbol TEXT PRIMARY KEY, qty REAL NOT NULL, avg_price REAL NOT NULL)""")
        c.execute("""CREATE TABLE IF NOT EXISTS trades
                     (id INTEGER PRIMARY KEY AUTOINCREMENT, time TEXT, symbol TEXT, side TEXT,
                      qty REAL, price REAL, fee REAL, reason TEXT)""")
        c.execute("""CREATE TABLE IF NOT EXISTS bot_state
                     (symbol TEXT PRIMARY KEY, last_candle TEXT, last_signal TEXT)""")
        if c.execute("SELECT COUNT(*) FROM account").fetchone()[0] == 0:
            c.execute("INSERT INTO account VALUES (1, ?)", (START_CASH,))

def get_cash():
    with connect() as c:
        return float(c.execute("SELECT cash FROM account WHERE id=1").fetchone()[0])

def get_positions():
    with connect() as c:
        rows = c.execute("SELECT symbol, qty, avg_price FROM positions ORDER BY symbol").fetchall()
    return pd.DataFrame(rows, columns=["Symbol", "Shares", "Average entry"])

def get_trades():
    with connect() as c:
        rows = c.execute("""SELECT time, symbol, side, qty, price, fee, reason
                            FROM trades ORDER BY id DESC LIMIT 200""").fetchall()
    return pd.DataFrame(rows, columns=["Time (UTC)", "Symbol", "Side", "Shares", "Fill price", "Fee", "Reason"])

def get_last_processed(symbol):
    with connect() as c:
        row = c.execute("SELECT last_candle FROM bot_state WHERE symbol=?", (symbol,)).fetchone()
    return row[0] if row else None

def mark_processed(symbol, candle, signal):
    with connect() as c:
        c.execute("""INSERT INTO bot_state(symbol,last_candle,last_signal) VALUES(?,?,?)
                     ON CONFLICT(symbol) DO UPDATE SET last_candle=excluded.last_candle,
                     last_signal=excluded.last_signal""", (symbol, candle, signal))

@st.cache_data(ttl=55, show_spinner=False)
def fetch_prices(symbol, api_key):
    if not api_key:
        return None, "API-Key fehlt."
    try:
        response = requests.get(
            "https://api.twelvedata.com/time_series",
            params={"symbol": symbol, "interval": INTERVAL, "outputsize": 250,
                    "apikey": api_key, "format": "JSON"},
            timeout=15,
        )
        response.raise_for_status()
        payload = response.json()
        if "values" not in payload:
            return None, payload.get("message", payload.get("code", "Keine Kursdaten erhalten."))
        df = pd.DataFrame(payload["values"])
        df["datetime"] = pd.to_datetime(df["datetime"])
        for col in ["open", "high", "low", "close", "volume"]:
            if col in df:
                df[col] = pd.to_numeric(df[col], errors="coerce")
        df = df.sort_values("datetime").dropna(subset=["close"]).reset_index(drop=True)
        df["SMA9"] = df["close"].rolling(9).mean()
        df["SMA21"] = df["close"].rolling(21).mean()
        return df, None
    except Exception as exc:
        return None, str(exc)

def get_position(symbol):
    p = get_positions()
    found = p[p["Symbol"] == symbol]
    if found.empty:
        return 0.0, 0.0
    return float(found.iloc[0]["Shares"]), float(found.iloc[0]["Average entry"])

def execute_paper_order(symbol, side, qty, market_price, reason):
    qty = float(qty)
    fill = market_price * (1 + SLIPPAGE_RATE if side == "BUY" else 1 - SLIPPAGE_RATE)
    notional = qty * fill
    fee = notional * FEE_RATE
    current_cash = get_cash()
    old_qty, old_avg = get_position(symbol)

    if side == "BUY":
        total = notional + fee
        if total > current_cash:
            raise ValueError("Nicht genug virtuelles Guthaben.")
        new_qty = old_qty + qty
        new_avg = ((old_qty * old_avg) + (qty * fill)) / new_qty if new_qty else fill
        with connect() as c:
            c.execute("UPDATE account SET cash=? WHERE id=1", (current_cash - total,))
            c.execute("""INSERT INTO positions(symbol,qty,avg_price) VALUES(?,?,?)
                         ON CONFLICT(symbol) DO UPDATE SET qty=excluded.qty,avg_price=excluded.avg_price""",
                      (symbol, new_qty, new_avg))
    else:
        if qty > old_qty + 1e-9:
            raise ValueError("Nicht genug virtuelle Stücke.")
        remaining = old_qty - qty
        with connect() as c:
            c.execute("UPDATE account SET cash=? WHERE id=1", (current_cash + notional - fee,))
            if remaining <= 1e-8:
                c.execute("DELETE FROM positions WHERE symbol=?", (symbol,))
            else:
                c.execute("UPDATE positions SET qty=? WHERE symbol=?", (remaining, symbol))
    with connect() as c:
        c.execute("""INSERT INTO trades(time,symbol,side,qty,price,fee,reason)
                     VALUES(?,?,?,?,?,?,?)""",
                  (datetime.now(timezone.utc).isoformat(timespec="seconds"),
                   symbol, side, qty, fill, fee, reason))

def portfolio_value(api_key):
    positions = get_positions()
    total = 0.0
    if positions.empty:
        return total
    for _, row in positions.iterrows():
        quote, _ = fetch_prices(row["Symbol"], api_key)
        if quote is not None and not quote.empty:
            total += float(row["Shares"]) * float(quote.iloc[-1]["close"])
    return total

def signal_for(df):
    if df is None or len(df) < 22:
        return "WARTEN", "Noch nicht genug Kursdaten für die Strategie."
    prev, last = df.iloc[-2], df.iloc[-1]
    if pd.isna(prev["SMA9"]) or pd.isna(prev["SMA21"]) or pd.isna(last["SMA9"]) or pd.isna(last["SMA21"]):
        return "WARTEN", "Indikatoren werden berechnet."
    if prev["SMA9"] <= prev["SMA21"] and last["SMA9"] > last["SMA21"]:
        return "KAUF", "SMA 9 ist über SMA 21 gekreuzt (bullisches Crossover)."
    if prev["SMA9"] >= prev["SMA21"] and last["SMA9"] < last["SMA21"]:
        return "VERKAUF", "SMA 9 ist unter SMA 21 gekreuzt (bärisches Crossover)."
    return "HALTEN", "Kein neues Crossover erkannt."

def run_auto_for(symbol, df, enabled, max_allocation_pct):
    if not enabled or df is None or df.empty:
        return None
    candle_id = str(df.iloc[-1]["datetime"])
    if get_last_processed(symbol) == candle_id:
        return None
    signal, reason = signal_for(df)
    price = float(df.iloc[-1]["close"])
    qty_held, _ = get_position(symbol)
    message = None
    try:
        if signal == "KAUF" and qty_held <= 1e-8:
            budget = get_cash() * max_allocation_pct / 100
            qty = round(budget / (price * (1 + FEE_RATE + SLIPPAGE_RATE)), 4)
            if qty > 0:
                execute_paper_order(symbol, "BUY", qty, price, "Auto: " + reason)
                message = f"{symbol}: virtueller Kauf von {qty} Stück ausgeführt."
        elif signal == "VERKAUF" and qty_held > 1e-8:
            execute_paper_order(symbol, "SELL", qty_held, price, "Auto: " + reason)
            message = f"{symbol}: virtuelle Position verkauft."
    except ValueError as exc:
        message = f"{symbol}: {exc}"
    mark_processed(symbol, candle_id, signal)
    return message

setup()
st_autorefresh(interval=REFRESH_MS, key="papertrade_refresh")

st.title("📈 PaperTrade Lab")
st.caption("Paper Trading mit Marktdaten · automatische Demo-Orders nur bei aktiviertem Bot · kein Echtgeldhandel")

with st.sidebar:
    st.header("Marktdaten")
    secret_key = ""
    try:
        secret_key = st.secrets.get("TWELVE_DATA_API_KEY", "")
    except Exception:
        pass
    api_key = secret_key or st.text_input("Twelve Data API-Key", type="password")
    symbol = st.selectbox("Aktie / ETF", WATCHLIST, index=0)
    st.caption("Datenintervall: 5 Minuten. Aktualisierung der App: ca. jede Minute, abhängig von Datenanbieter und Tarif.")
    st.divider()
    st.header("Automatischer Demo-Bot")
    bot_enabled = st.toggle("Bot aktivieren", value=False)
    max_allocation = st.slider("Max. Anteil des freien Guthabens je Kauf", 1, 10, 5)
    st.caption("Strategie: SMA 9/21 Crossover. Long-only, kein Leerverkauf.")
    st.warning("Wenn aktiviert, werden Signale ohne weitere Bestätigung als virtuelle Orders ausgeführt. Nur Demo.")
    st.divider()
    if st.button("Demo-Konto zurücksetzen", use_container_width=True):
        with connect() as c:
            c.execute("DELETE FROM positions")
            c.execute("DELETE FROM trades")
            c.execute("DELETE FROM bot_state")
            c.execute("UPDATE account SET cash=? WHERE id=1", (START_CASH,))
        st.rerun()

if not api_key:
    st.info("Gib links deinen Twelve Data API-Key ein oder hinterlege ihn in Streamlit unter App settings → Secrets als TWELVE_DATA_API_KEY.")
    st.stop()

# Fetch the selected chart and the watchlist symbols.
frames = {}
errors = {}
for s in WATCHLIST:
    frames[s], errors[s] = fetch_prices(s, api_key)

selected = frames.get(symbol)
if selected is None or selected.empty:
    st.error(f"Für {symbol} konnten keine Intraday-Daten geladen werden: {errors.get(symbol)}")
    st.info("Prüfe, ob dein Twelve Data Tarif 5-Minuten-Daten für dieses Symbol unterstützt und ob dein API-Kontingent ausreicht.")
    st.stop()

# Run only on newly received candles. The DB prevents duplicate orders on reruns.
auto_messages = []
if bot_enabled:
    # Auto-trading applies only to the symbol currently selected in the sidebar.
    msg = run_auto_for(symbol, selected, True, max_allocation)
    if msg:
        auto_messages.append(msg)

for msg in auto_messages:
    st.success(msg)

cash_now = get_cash()
positions_df = get_positions()
market_val = portfolio_value(api_key)
equity = cash_now + market_val
trades_df = get_trades()
wins = 0
if not trades_df.empty:
    # Count completed round trips approximately by comparing realized trade sequence is intentionally not labeled win rate.
    wins = len(trades_df[trades_df["Side"] == "SELL"])

m1, m2, m3, m4 = st.columns(4)
m1.metric("Virtuelles Gesamtvermögen", f"${equity:,.2f}", f"{equity-START_CASH:+,.2f} $")
m2.metric("Freies Guthaben", f"${cash_now:,.2f}")
m3.metric("Marktwert Positionen", f"${market_val:,.2f}")
m4.metric("Bot-Status", "AKTIV" if bot_enabled else "AUS")

st.subheader("Marktübersicht")
watch_cols = st.columns(len(WATCHLIST))
for col, s in zip(watch_cols, WATCHLIST):
    frame = frames.get(s)
    if frame is not None and not frame.empty:
        last = float(frame.iloc[-1]["close"])
        previous = float(frame.iloc[-2]["close"]) if len(frame) > 1 else last
        col.metric(s, f"${last:,.2f}", f"{last-previous:+.2f}")
    else:
        col.metric(s, "—", "Daten nicht verfügbar")

st.subheader(f"{symbol} · 5-Minuten-Kursverlauf")
chart = go.Figure()
chart.add_trace(go.Candlestick(x=selected["datetime"], open=selected["open"], high=selected["high"],
                               low=selected["low"], close=selected["close"], name="Kurs"))
chart.add_trace(go.Scatter(x=selected["datetime"], y=selected["SMA9"], name="SMA 9"))
chart.add_trace(go.Scatter(x=selected["datetime"], y=selected["SMA21"], name="SMA 21"))
chart.update_layout(template="plotly_dark", height=470, xaxis_rangeslider_visible=False,
                    margin=dict(l=5, r=5, t=25, b=5))
st.plotly_chart(chart, use_container_width=True)

sig, explanation = signal_for(selected)
sig_col = "🟢" if sig == "KAUF" else "🔴" if sig == "VERKAUF" else "⚪"
st.subheader("Strategie-Signal")
st.write(f"**{sig_col} {sig}** — {explanation}")
st.caption("Ein Crossover ist ein einfaches Lernsignal, keine verlässliche Prognose. Kurse können verzögert sein.")

tab1, tab2, tab3 = st.tabs(["Portfolio", "Trade-Historie", "Strategie & Hinweise"])
with tab1:
    if positions_df.empty:
        st.info("Noch keine offenen virtuellen Positionen.")
    else:
        view = positions_df.copy()
        current_prices = {s: float(frames[s].iloc[-1]["close"]) for s in frames if frames[s] is not None and not frames[s].empty}
        view["Letzter Kurs"] = view["Symbol"].map(current_prices)
        view["Marktwert"] = view["Shares"] * view["Letzter Kurs"]
        view["Unrealisierter Gewinn/Verlust"] = (view["Letzter Kurs"] - view["Average entry"]) * view["Shares"]
        st.dataframe(view, use_container_width=True, hide_index=True)
with tab2:
    if trades_df.empty:
        st.info("Noch keine Trades. Aktiviere den Bot oder nutze später manuelle Demo-Orders.")
    else:
        st.dataframe(trades_df, use_container_width=True, hide_index=True)
with tab3:
    st.markdown("""
    **Aktuelle Demo-Regeln**
    - Virtuelles Startkapital: 10.000 US-Dollar
    - Strategie: SMA 9 / SMA 21 auf 5-Minuten-Kerzen
    - Automatik handelt nur das aktuell ausgewählte Symbol\n    - Kauf: SMA 9 kreuzt SMA 21 nach oben und es besteht noch keine Position
    - Verkauf: SMA 9 kreuzt SMA 21 nach unten und eine Position besteht
    - Long-only; keine Kredite und keine Leerverkäufe
    - Maximaler Kaufbetrag: einstellbarer Anteil des freien virtuellen Guthabens
    - Simulierte Gebühren: 0,10 %; Slippage-Annahme: 0,05 %
    - Automatische Orders werden nur beim Empfang einer neuen Kerze geprüft
    """)
    st.warning("Der Bot arbeitet nur, solange die Streamlit-App aktiv läuft und regelmäßig aktualisiert wird. Cloud-Schlafphasen, API-Limits, verzögerte Daten und Ausführungsannahmen können das Ergebnis beeinflussen. Das ist kein echtes Börsen- oder Broker-System.")

st.caption("PaperTrade Lab v2 · Simulation only · Automatik handelt nur das ausgewählte Symbol · keine Verbindung zu einem Broker · keine Echtgeld-Orders.")
