# PaperTrade Lab v2

iPad-freundliches Paper-Trading-Dashboard mit:
- 5-Minuten-Kursdaten über Twelve Data (sofern im API-Tarif verfügbar)
- Watchlist (AAPL, MSFT, NVDA, SPY, QQQ)
- SMA 9/21 Crossover-Lernstrategie
- Optional aktivierbarer automatischer Demo-Handel
- Portfolio, virtuelle Trades, Gebühren und Slippage
- SQLite-Speicherung

## GitHub / Streamlit Update
Ersetze in deinem bestehenden GitHub-Repository `app.py` durch diese neue `app.py` und `requirements.txt` durch die neue `requirements.txt`. Streamlit erkennt den Commit und startet einen neuen Deploy.

## API-Key sicher hinterlegen
In Streamlit Cloud: Manage app → Settings → Secrets:
```toml
TWELVE_DATA_API_KEY = "DEIN_API_KEY"
```
Danach App neu starten. Alternativ kann der Key im Seitenmenü eingegeben werden. Niemals in GitHub-Code oder Screenshots veröffentlichen.

## Hinweis
Nur Simulation. Es gibt keine Broker-Verbindung und keine Echtgeld-Orders. Intraday-Daten, Symbole, Verzögerungen und API-Limits hängen vom Twelve Data Tarif ab. Automatik läuft nur solange die App aktiv ist und aktualisiert wird. Die Strategie ist ein einfaches Lernbeispiel und keine Gewinnzusage.
